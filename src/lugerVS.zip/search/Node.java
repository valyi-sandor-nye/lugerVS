/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package search;

/**
 *
 * @author valyis
 */
public class Node {
    State state;
    Node parent;
    int numberOfUsedUpChildren;    
    
    
}
